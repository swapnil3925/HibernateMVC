package cm.csi.dao;

import com.csi.model.Employee;

public interface EmployeeDao {
	
	public void save(Employee employee);
	
	public void show();

}
