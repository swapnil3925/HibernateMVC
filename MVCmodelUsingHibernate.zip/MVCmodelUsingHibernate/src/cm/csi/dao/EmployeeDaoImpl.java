package cm.csi.dao;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.csi.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	
	private static SessionFactory factory=new AnnotationConfiguration().configure().buildSessionFactory();

	@Override
	public void save(Employee employee) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(employee);
		transaction.commit();
		
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		@SuppressWarnings("unchecked")
		List<Employee> empList=session.createQuery("from Employee").list();
		
		for(Employee e: empList)
		{
			System.out.println(e);
		}
		
	}

}
