package com.csi.controller;

import com.csi.model.Employee;
import com.csi.service.EmployeeService;
import com.csi.service.EmployeeServiceImpl;

public class EmployeeController {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeService employeeService=new EmployeeServiceImpl();
		Employee employee=new Employee();
		employee.setEmpName("Swapnil");
		employee.setEmpAddress("Ashta");
		employee.setEmpEmailId("swapnil@gmail.com");
		employee.setEmpContactNumber(7028653925L);
		
		employeeService.save(employee);
		System.out.println("Data save sucessfully...");
		employeeService.show();
		

	}

}
