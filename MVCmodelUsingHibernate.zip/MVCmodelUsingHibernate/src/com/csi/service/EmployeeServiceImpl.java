package com.csi.service;

import com.csi.model.Employee;

import cm.csi.dao.EmployeeDao;
import cm.csi.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDao employeeDaoImpl=new EmployeeDaoImpl();
	@Override
	public void save(Employee employee) {
		// TODO Auto-generated method stub
		employeeDaoImpl.save(employee);
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		employeeDaoImpl.show();
	}

}
