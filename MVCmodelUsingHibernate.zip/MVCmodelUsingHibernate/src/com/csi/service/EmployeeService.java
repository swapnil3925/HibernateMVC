package com.csi.service;

import com.csi.model.Employee;

public interface EmployeeService {
	public void save(Employee employee);
	
	public void show();

}
