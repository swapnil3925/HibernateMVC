package com.csi.dao;

import com.csi.model.User;

public interface UserDao {
	
	public void signup(User user);
	
	public boolean signin(String userEmail,String userPassword);

}
