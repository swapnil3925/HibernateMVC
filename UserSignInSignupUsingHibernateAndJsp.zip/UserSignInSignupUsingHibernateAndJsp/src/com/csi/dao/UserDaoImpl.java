package com.csi.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.csi.model.User;

public class UserDaoImpl implements UserDao{
private static SessionFactory factory=new AnnotationConfiguration().configure().buildSessionFactory();
	@Override
	public void signup(User user) {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(user);
		transaction.commit();
		
	}

	@Override
	public boolean signin(String userEmail, String userPassword) {
		boolean flag=false;
		Session session=factory.openSession();
		@SuppressWarnings("unchecked")
		List<User> userList=session.createQuery("from User").list();
		
		for(User u:userList)
		{
			if(u.getUserEmail().equalsIgnoreCase(userEmail) && u.getUserPassword().equals(userPassword))
			{
				flag=true;
			}
		}
		
		return flag;
	}

}
