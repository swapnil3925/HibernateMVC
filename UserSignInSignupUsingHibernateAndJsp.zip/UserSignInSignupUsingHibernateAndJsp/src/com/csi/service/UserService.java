package com.csi.service;

import com.csi.model.User;

public interface UserService {
	
	public void signup(User user);
	
	public boolean signin(String userEmail,String userPassword);

}
