package com.csi.service;

import com.csi.dao.UserDao;
import com.csi.dao.UserDaoImpl;
import com.csi.model.User;

public class UserServiceImpl implements UserService{
	UserDao userDaoImpl=new UserDaoImpl();

	@Override
	public void signup(User user) {
		// TODO Auto-generated method stub
		userDaoImpl.signup(user);
		
		
	}

	@Override
	public boolean signin(String userEmail, String userPassword) {
		// TODO Auto-generated method stub
		return userDaoImpl.signin(userEmail, userPassword);
	}

}
