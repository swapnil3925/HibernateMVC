package com.csi.jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Address {
	@Id
	@GeneratedValue
	private int addrId;
	
	private String streetAddr;
	
	private String cityAddr;
	
	private String stateAddr;
	
	private String countryAddr;
	
	private long pinCode;
	
	@ManyToOne
	private Employee employee;

	public Address(String streetAddr, String cityAddr, String stateAddr, String countryAddr, long pinCode,
			Employee employee) {
		super();
		this.streetAddr = streetAddr;
		this.cityAddr = cityAddr;
		this.stateAddr = stateAddr;
		this.countryAddr = countryAddr;
		this.pinCode = pinCode;
		this.employee = employee;
	}
	
	

}
