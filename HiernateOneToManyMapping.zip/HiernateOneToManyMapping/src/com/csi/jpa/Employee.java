package com.csi.jpa;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Employee {

	
	@Id
	@GeneratedValue
	private int empId;
	
	private String empName;
	
	private double empSalary;
	
	@OneToMany
	private List<Address> addresses;

	public Employee(String empName, double empSalary) {
		super();
		this.empName = empName;
		this.empSalary = empSalary;
		
	}
	
	
	
	
}
