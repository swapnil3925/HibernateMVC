package com.csi.jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Address {

	@Id
	@GeneratedValue
	private int addId;
	
	private String addStreet;
	
	private String addcity;
	
	private String addState;
	
	private String addCounty;
	
	private long pinCode;

	public Address(String addStreet, String addcity, String addState, String addCounty, long pinCode) {
		super();
		
		this.addStreet = addStreet;
		this.addcity = addcity;
		this.addState = addState;
		this.addCounty = addCounty;
		this.pinCode = pinCode;
	}
	
	
	
}
