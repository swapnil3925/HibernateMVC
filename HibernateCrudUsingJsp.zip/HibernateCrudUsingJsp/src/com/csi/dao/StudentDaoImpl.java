package com.csi.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.csi.model.Student;

public class StudentDaoImpl implements StudentDao {
	private static SessionFactory factory=new AnnotationConfiguration().configure().buildSessionFactory();

	@Override
	public void signup(Student student) {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(student);
		transaction.commit();
		
	}

	@Override
	public boolean signin(String studEmailId, String password) {
		boolean status=false;
		Session session=factory.openSession();
		List<Student> studList=session.createQuery("from Student").list();
		for(Student s: studList)
		{
			if(s.getStudEmailid().equalsIgnoreCase(studEmailId) && s.getPassword().equals(password))
			{
				status=true;
			}
		}
		
		return status;
	}

	@Override
	public void updateStudData(int studId, Student student) {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		List<Student> studList=session.createQuery("from Student").list();
		
		for(Student s: studList)
		{
			if(s.getStudId()==studId)
			{
				s.setStudFirstName(student.getStudFirstName());
				s.setStudeLastName(student.getStudeLastName());
				s.setStudEmailid(student.getStudEmailid());
				s.setPassword(student.getPassword());
				s.setStudAddress(student.getStudAddress());
				session.update(s);
				transaction.commit();
			}
		}
		
		
		
	}

	@Override
	public void deleteStudData(int studId) {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		List<Student> studList=session.createQuery("from Student").list();
		for(Student s: studList)
		{
			if(s.getStudId()==studId)
			{
				session.delete(s);
				transaction.commit();
			}
		}
			
	}

	@Override
	public List<Student> getAllStudData() {
		Session session=factory.openSession();
		List<Student> studList=session.createQuery("from Student").list();
		return studList;
	}

	@Override
	public Student getDataById(int studId) {
		Session session=factory.openSession();
		List<Student> studList=session.createQuery("from Student").list();
		Student student=new Student();
		for(Student s:studList)
		{
			if(s.getStudId()==studId)
			{
				student.setStudId(s.getStudId());
				student.setStudFirstName(s.getStudFirstName());
				student.setStudeLastName(s.getStudeLastName());
				student.setStudAddress(s.getStudAddress());
				student.setStudEmailid(s.getStudEmailid());
				student.setPassword(s.getPassword());
			}
		}
				
		return student;
	}

}
