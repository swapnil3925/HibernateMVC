package com.csi.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student {
	
	@Id
	@GeneratedValue
	private int studId;
	
	private String studFirstName;
	
	private String studeLastName;
	
	private String studEmailid;
	
	private String password;
 	
	private String studAddress;

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public String getStudFirstName() {
		return studFirstName;
	}

	public void setStudFirstName(String studFirstName) {
		this.studFirstName = studFirstName;
	}

	public String getStudeLastName() {
		return studeLastName;
	}

	public void setStudeLastName(String studeLastName) {
		this.studeLastName = studeLastName;
	}

	public String getStudEmailid() {
		return studEmailid;
	}

	public void setStudEmailid(String studEmailid) {
		this.studEmailid = studEmailid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStudAddress() {
		return studAddress;
	}

	public void setStudAddress(String studAddress) {
		this.studAddress = studAddress;
	}
	

}
