package com.csi.service;

import java.util.List;

import com.csi.dao.StudentDao;
import com.csi.dao.StudentDaoImpl;
import com.csi.model.Student;

public class StudentServiceImpl implements StudentService {
	 StudentDao studDaoImpl=new StudentDaoImpl();
	@Override
	public void signup(Student student) {
		// TODO Auto-generated method stub
		studDaoImpl.signup(student);
		
	}

	@Override
	public boolean signin(String studEmailId, String password) {
		// TODO Auto-generated method stub
		return studDaoImpl.signin(studEmailId, password);
	}

	@Override
	public void updateStudData(int studId, Student student) {
		// TODO Auto-generated method stub
		studDaoImpl.updateStudData(studId, student);
	}

	@Override
	public void deleteStudData(int studId) {
		// TODO Auto-generated method stub
		studDaoImpl.deleteStudData(studId);
	}

	@Override
	public List<Student> getAllStudData() {
		// TODO Auto-generated method stub
		return studDaoImpl.getAllStudData();
	}

	@Override
	public Student getDataById(int studId) {
		// TODO Auto-generated method stub
		return studDaoImpl.getDataById(studId);
	}

}
