package com.csi.service;

import java.util.List;

import com.csi.model.Student;

public interface StudentService {
	public void signup(Student student);
	
	public boolean signin(String studEmailId, String password);
	
	public void updateStudData(int studId,Student student);
	
	public void deleteStudData(int studId);
	
	public List<Student> getAllStudData();
	
	public Student getDataById(int studId);

}
