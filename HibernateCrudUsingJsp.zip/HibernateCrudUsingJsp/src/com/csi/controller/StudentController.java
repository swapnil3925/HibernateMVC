package com.csi.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.csi.model.Student;
import com.csi.service.StudentService;
import com.csi.service.StudentServiceImpl;


@WebServlet("/StudentController")
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String SHOWSTUDENT="/liststudent.jsp";
	String SIGNUP="/signup.jsp";
	String SIGNIN="/signin.jsp";
	String HOMEPAGE="/index.jsp";
	String WELCOME="/welcome.jsp";
	String EDITDATA="/edit.jsp";
	
	StudentService studServiceImpl=new StudentServiceImpl();
  
    public StudentController() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String redirect="";
		String action=request.getParameter("action");
		
		if(action.equals("signup"))
		{
			String studFirstName=request.getParameter("studfirstname");
			String studLastName=request.getParameter("studlastname");
			String studAddress=request.getParameter("studaddress");
			String studEmailId=request.getParameter("studemailid");
			String studPassword=request.getParameter("studpassword");
			
			Student student=new Student();
			student.setStudFirstName(studFirstName);
			student.setStudeLastName(studLastName);
			student.setStudAddress(studAddress);
			student.setStudEmailid(studEmailId);
			student.setPassword(studPassword);
			
			studServiceImpl.signup(student);
			System.out.println("Student Sign Up Successfully...");
			redirect=HOMEPAGE;
			
			
			
		}
		else if(action.equals("signin"))
		{
			String studEmailId=request.getParameter("studemailid");
			String studPassword=request.getParameter("studpassword");
			
			if(studServiceImpl.signin(studEmailId, studPassword))
			{
				redirect=WELCOME;
			}
			else
			{
				redirect=SIGNIN;
			}
			
		}
		else if(action.equals("editform"))
		{
			redirect=EDITDATA;
			
		}
		else if(action.equals("edit"))
		{
			int studId=Integer.valueOf(request.getParameter("studid"));
			String studFirstName=request.getParameter("studfirstname");
			String studLastName=request.getParameter("studlastname");
			String studAddress=request.getParameter("studaddress");
			String studEmailId=request.getParameter("studemailid");
			String studPassword=request.getParameter("studpassword");
			
			Student student=new Student();
			
			student.setStudFirstName(studFirstName);
			student.setStudeLastName(studLastName);
			student.setStudAddress(studAddress);
			student.setStudEmailid(studEmailId);
			student.setPassword(studPassword);
			
			studServiceImpl.updateStudData(studId, student);
			System.out.println("Student data updated successfully");
			redirect=SHOWSTUDENT;
			
			
			
			
		}
		else if(action.equals("showstudent"))
		{
			redirect=SHOWSTUDENT;
			
		}
		else if(action.equals("delete"))
		{
			int studId=Integer.valueOf(request.getParameter("studid"));
			studServiceImpl.deleteStudData(studId);
			redirect=SHOWSTUDENT;
		}
		RequestDispatcher rd=request.getRequestDispatcher(redirect);
		rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
