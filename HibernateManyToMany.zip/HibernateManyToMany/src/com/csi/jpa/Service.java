package com.csi.jpa;

import java.util.LinkedList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Service {
	private static SessionFactory factory=new AnnotationConfiguration().configure().buildSessionFactory();

	public static void main(String[] args) {
		
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		Address a1=new Address();
		a1.setAddstreet("Inspiria Mall");
		a1.setAddCity("Pune");
		a1.setAddState("MH");
		a1.setAddCountry("India");
		a1.setPinCode(415452);
		session.save(a1);
		
		Address a2=new Address();
		a2.setAddstreet("Gandhinagar");
		a2.setAddCity("Ashta");
		a2.setAddState("MH");
		a2.setAddCountry("India");
		a2.setPinCode(416301);
		session.save(a2);
		
		List<Address> addList=new LinkedList<>();
		
		addList.add(a1);
		addList.add(a2);
		
		Employee e1=new Employee();
		e1.setEmpName("Swapnil");
		e1.setEmpSalary(452000);
		e1.setAddress(addList);
		session.save(e1);
		
		
		Employee e2=new Employee();
		e2.setEmpName("Ganesh");
		e2.setEmpSalary(485000);
		e2.setAddress(addList);
		
		session.save(e2);
		System.out.println("Data add Sucessfully");
		transaction.commit();
		
	}

}
