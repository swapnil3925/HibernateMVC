package com.csi.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Dob {
	
	@Id
	@GeneratedValue
	private int dobID;
	
	private Date dob;

	public int getDobID() {
		return dobID;
	}

	public void setDobID(int dobID) {
		this.dobID = dobID;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Dob [dobID=" + dobID + ", dob=" + dob + "]";
	}
	
	

}
