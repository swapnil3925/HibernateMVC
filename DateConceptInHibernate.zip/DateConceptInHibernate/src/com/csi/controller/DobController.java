package com.csi.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.csi.model.Dob;
import com.csi.service.DobServiceImpl;
import com.csi.service.Dobservice;

public class DobController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dobservice dobServiceImpl=new DobServiceImpl();
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		Dob dob=new Dob();
		System.out.println("Enter Dob in dd-mm-yyyy: ");
		String date=sc.next();
		Date d=null;
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		try {
			d=sdf.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dob.setDob(d);
		dobServiceImpl.save(dob);
		System.out.println("DOB added sucessfully..");
		
//		DateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
//		try {
//			formatter.format(formatter.parse(date));
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		dob.setDob(date);
	//	dob.setDob(new Date());
		
		//dobServiceImpl.save(dob);

	}

}
