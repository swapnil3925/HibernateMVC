package com.csi.dao;

import com.csi.model.Dob;

public interface DobDao {
			
	public void save(Dob dob);
	
			
}
