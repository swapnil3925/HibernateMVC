package com.csi.service;

import com.csi.dao.DobDao;
import com.csi.dao.DobDaoImpl;
import com.csi.model.Dob;

public class DobServiceImpl implements Dobservice {

	DobDao dobDaoimpl=new DobDaoImpl();
	@Override
	public void save(Dob dob) {
		// TODO Auto-generated method stub
		dobDaoimpl.save(dob);
		
		
	}

}
