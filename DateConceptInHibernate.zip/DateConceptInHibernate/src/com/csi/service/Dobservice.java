package com.csi.service;

import com.csi.model.Dob;

public interface Dobservice {
	public void save(Dob dob);

}
