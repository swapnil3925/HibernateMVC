package com.csi.service;

import com.csi.dao.StudentDao;
import com.csi.dao.StudentDaoImpl;
import com.csi.model.Student;

public class StudentServiceImpl implements StudentService {

	StudentDao studentDaoImpl=new StudentDaoImpl();
	@Override
	public void saveData(Student student) {
		// TODO Auto-generated method stub
		studentDaoImpl.saveData(student);
		
	}

	@Override
	public void updateData(int studId, Student student) {
		// TODO Auto-generated method stub
		studentDaoImpl.updateData(studId, student);
	}

	@Override
	public void getAllData() {
		// TODO Auto-generated method stub
		studentDaoImpl.getAllData();
		
	}

	@Override
	public void getAllDataById(int studId) {
		// TODO Auto-generated method stub
		studentDaoImpl.getAllDataById(studId);
	}

	@Override
	public void deleteDatabyId(int studId) {
		// TODO Auto-generated method stub
		studentDaoImpl.deleteDatabyId(studId);
	}

}
