package com.csi.service;

import com.csi.model.Student;

public interface StudentService {
public void saveData(Student student);
	
	public void updateData(int studId,Student student);
	
	public void getAllData();
	
	public void getAllDataById(int studId);
	
	public void deleteDatabyId(int studId);

}
