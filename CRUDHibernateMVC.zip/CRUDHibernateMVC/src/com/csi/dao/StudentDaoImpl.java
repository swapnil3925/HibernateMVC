package com.csi.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.csi.model.Student;

public class StudentDaoImpl implements StudentDao {
	private static SessionFactory factory=new AnnotationConfiguration().configure().buildSessionFactory();

	@Override
	public void saveData(Student student) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(student);
		transaction.commit();
	}

	@Override
	public void updateData(int studId, Student student) {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		List<Student> studList=session.createQuery("from Student").list();
		for(Student s:studList)
		{
			if(s.getStudId()==studId)
			{
				s.setStudName(student.getStudName());
				s.setStudEmail(student.getStudEmail());
				s.setStudAddress(student.getStudAddress());
				s.setStudContactNumber(student.getStudContactNumber());
				s.setStudDOB(student.getStudDOB());
				
				session.update(s);
				transaction.commit();
			}
		}
		
	}

	@Override
	public void getAllData() {
			Session session=factory.openSession();
			List<Student> studList=session.createQuery("from Student").list();
			for(Student s:studList)
			{
				System.out.println(s);
			}
		
	}

	@Override
	public void getAllDataById(int studId) {
		// TODO Auto-generated method stub
		Session session =factory.openSession();
		List<Student> studlist=session.createQuery("from Student").list();
		for(Student s:studlist)
		{
			if(s.getStudId()==studId)
			{
				System.out.println(s);
			}
		}
		
	}

	@Override
	public void deleteDatabyId(int studId) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		List<Student> studList=session.createQuery("from Student").list();
		
		for(Student s: studList)
		{
			if(s.getStudId()==studId)
			{
				session.delete(s);
				transaction.commit();
			}
		}
		
	}

}
