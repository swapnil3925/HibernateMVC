package com.csi.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student {
	
	@Id
	@GeneratedValue
	private int studId;
	
	private String studName;
	
	private String studAddress;
	
	private String studEmail;
	
	private long studContactNumber;
	
	private Date studDOB;

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public String getStudAddress() {
		return studAddress;
	}

	public void setStudAddress(String studAddress) {
		this.studAddress = studAddress;
	}

	public String getStudEmail() {
		return studEmail;
	}

	public void setStudEmail(String studEmail) {
		this.studEmail = studEmail;
	}

	public long getStudContactNumber() {
		return studContactNumber;
	}

	public void setStudContactNumber(long studContactNumber) {
		this.studContactNumber = studContactNumber;
	}

	public Date getStudDOB() {
		return studDOB;
	}

	public void setStudDOB(Date studDOB) {
		this.studDOB = studDOB;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", studAddress=" + studAddress + ", studEmail="
				+ studEmail + ", studContactNumber=" + studContactNumber + ", studDOB=" + studDOB + "]";
	}
	
	
}
