package com.csi.controller;

import java.util.Date;

import com.csi.model.Student;
import com.csi.service.StudentService;
import com.csi.service.StudentServiceImpl;

public class StudentController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentService studentServiceImpl=new StudentServiceImpl();
		Student student=new Student();
		student.setStudName("ganesh");
		student.setStudAddress("satara");
		student.setStudContactNumber(7030370316L);
		student.setStudEmail("gana3925@gmail.com");
		student.setStudDOB(new Date());
		
	//	studentServiceImpl.saveData(student);
		//studentServiceImpl.getAllData();
		//studentServiceImpl.getAllDataById(2);
		//studentServiceImpl.updateData(2, student);
		studentServiceImpl.deleteDatabyId(2);
		
		

	}

}
