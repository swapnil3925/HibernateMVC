package com.csi.jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Address {

	@Id
	@GeneratedValue
	private int addId;
	
	private String addStreet;
	
	private String addCity;
	
	private String addState;
	
	private String addCountry;
	
	private long pinCode;

	public Address(String addStreet, String addCity, String addState, String addCountry, long pinCode) {
		super();
		this.addStreet = addStreet;
		this.addCity = addCity;
		this.addState = addState;
		this.addCountry = addCountry;
		this.pinCode = pinCode;
	}
	
	
	
}
