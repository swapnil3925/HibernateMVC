package com.csi.jpa;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Service {

	private static SessionFactory factory=new AnnotationConfiguration().configure().buildSessionFactory();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		Address a1=new Address("Inspiria Mall", "Pune", "MH", "India", 456123);
		session.save(a1);
		
		Employee e1=new Employee("Swapnil", 45000, a1);
		Employee e2=new Employee("Ganesh", 48000, a1);
		session.save(e1);
		System.out.println("data add sucessfully...");
		transaction.commit();
		

	}

}
